console.log('Loading function');

export const handler = async (event, context) => {
    return "Hello, world from terraform"
};
